package apply;

public class ApplyDTO {

}
