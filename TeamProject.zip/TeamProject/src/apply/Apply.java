package apply;

public interface Apply {

}
