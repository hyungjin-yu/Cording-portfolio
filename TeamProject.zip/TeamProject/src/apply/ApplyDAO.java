package apply;

public class ApplyDAO {

}
