package apply;

public interface Apply {
	public String from_login ();
	public String form_admin();
	public String apply();
}
